﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoAgendaContatos
{
    public partial class FrmRelatorio : Form
    {
        public FrmRelatorio()
        {
            InitializeComponent();
        }

        private void frmRelatorio_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'DS_Contatos.tbcontato'. Você pode movê-la ou removê-la conforme necessário.
            this.tbcontatoTableAdapter.Fill(this.DS_Contatos.tbcontato);

            this.reportViewer1.RefreshReport();
        }

    }
}
